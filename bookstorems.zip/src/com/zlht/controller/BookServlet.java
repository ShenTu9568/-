package com.zlht.controller;

import com.zlht.entity.Book;
import com.zlht.entity.Employee;
import com.zlht.service.AuthorService;
import com.zlht.service.BookService;
import com.zlht.service.CategoryService;
import com.zlht.service.imp.AuthorServiceImp;
import com.zlht.service.imp.BookServiceImp;
import com.zlht.service.imp.CategoryServiceImp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/book")
public class BookServlet extends HttpServlet {

    BookService bookService = new BookServiceImp();
    AuthorService authorService = new AuthorServiceImp();
    CategoryService categoryService = new CategoryServiceImp();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        switch (method) {
            case "list":
                req.setAttribute("list", this.bookService.list());
                req.setAttribute("authorList", this.authorService.list());
                req.setAttribute("categoryList",this.categoryService.list());
                req.getRequestDispatcher("bookmanager.jsp").forward(req, resp);
                break;
            case "search":
                String key = req.getParameter("key");
                String value = req.getParameter("value");
                req.setAttribute("list", this.bookService.search(key, value));
                req.getRequestDispatcher("bookmanager.jsp").forward(req, resp);
                break;
            case "save":
                String name = req.getParameter("name");
                int author_id = Integer.parseInt(req.getParameter("author_id"));
                String price = req.getParameter("price");
                String publisher = req.getParameter("publisher");
                String date = req.getParameter("date");
                int category_id = Integer.parseInt(req.getParameter("category_id"));

                this.bookService.save(new Book(name,author_id,price,publisher,date,category_id));
                resp.sendRedirect("/book?method=list");
                break;
            case "update":
                Integer id = Integer.parseInt(req.getParameter("id"));
                name = req.getParameter("name");
                author_id = Integer.parseInt(req.getParameter("author_id"));
                price = req.getParameter("price");
                publisher = req.getParameter("publisher");
                date = req.getParameter("date");
                category_id = Integer.parseInt(req.getParameter("category_id"));


                this.bookService.update(new Book(id,name,author_id,price,publisher,date,category_id));
                resp.sendRedirect("/book?method=list");
                break;
            case "delete":
                id = Integer.parseInt(req.getParameter("id"));
                this.bookService.delete(id);
                resp.sendRedirect("/book?method=list");
                break;
        }
    }
}
