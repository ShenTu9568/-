package com.zlht.controller;

import com.zlht.entity.Category;
import com.zlht.entity.Store;
import com.zlht.service.CategoryService;
import com.zlht.service.imp.CategoryServiceImp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/category")
public class CategoryServlet extends HttpServlet {

    CategoryService categoryService = new CategoryServiceImp();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        switch (method) {
            case "list":
                req.setAttribute("list", this.categoryService.list());
                req.getRequestDispatcher("categorymanager.jsp").forward(req, resp);
                break;
            case "search":
                String key = req.getParameter("key");
                String value = req.getParameter("value");
                req.setAttribute("list",this.categoryService.search(key ,value));
                req.getRequestDispatcher("categorymanager.jsp").forward(req, resp);
                break;
            case "save":
                String name = req.getParameter("name");
                String introduce = req.getParameter("introduce");
                String position = req.getParameter("position");
                this.categoryService.save(new Category(name,introduce,position));
                resp.sendRedirect("/category?method=list");
                break;
            case "update":
                String idStr = req.getParameter("id");
                Integer id = Integer.parseInt(idStr);
                name = req.getParameter("name");
                introduce = req.getParameter("introduce");
                position = req.getParameter("position");
                this.categoryService.update(new Category(id,name,introduce,position));
                resp.sendRedirect("/category?method=list");
                break;
            case "delete":
                idStr = req.getParameter("id");
                id = Integer.parseInt(idStr);
                this.categoryService.delete(id);
                resp.sendRedirect("/category?method=list");
                break;
        }
    }
}
