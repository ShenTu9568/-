package com.zlht.controller;

import com.zlht.entity.Book;
import com.zlht.entity.Comment;
import com.zlht.service.BookService;
import com.zlht.service.CommentService;
import com.zlht.service.CustomerService;
import com.zlht.service.StoreService;
import com.zlht.service.imp.BookServiceImp;
import com.zlht.service.imp.CommentServiceImp;
import com.zlht.service.imp.CustomerServiceImp;
import com.zlht.service.imp.StoreServiceImp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/comment")
public class Commentservelt extends HttpServlet {

    CommentService commentService = new CommentServiceImp();
    StoreService StoreService = new StoreServiceImp();
    BookService bookService = new BookServiceImp();
    CustomerService customerService = new CustomerServiceImp();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        switch (method) {
            case "list":
                req.setAttribute("list", this.commentService.list());
                req.setAttribute("bookList", this.bookService.list());
                req.setAttribute("storeList", this.StoreService.list());
                req.setAttribute("customerList", this.customerService.list());
                req.getRequestDispatcher("commentmanager.jsp").forward(req, resp);
                break;
            case "search":
                String key = req.getParameter("key");
                String value = req.getParameter("value");
                req.setAttribute("list", this.bookService.search(key, value));
                req.getRequestDispatcher("commentmanager.jsp").forward(req, resp);
                break;
            case "save":
                int book_id = Integer.parseInt(req.getParameter("book_id"));
                int store_id = Integer.parseInt(req.getParameter("store_id"));
                int customer_id = Integer.parseInt(req.getParameter("customer_id"));
                String date = req.getParameter("date");
                String content = req.getParameter("content");

                this.commentService.save(new Comment(book_id,store_id,customer_id,date,content));
                resp.sendRedirect("/comment?method=list");
                break;
            case "update":
                book_id = Integer.parseInt(req.getParameter("book_id"));
                store_id = Integer.parseInt(req.getParameter("store_id"));
                customer_id = Integer.parseInt(req.getParameter("customer_id"));
                date = req.getParameter("date");
                content = req.getParameter("content");
                Integer id = Integer.parseInt(req.getParameter("id"));

                this.commentService.update(new Comment(id,book_id,store_id,customer_id,date,content));
                resp.sendRedirect("/comment?method=list");
                break;
            case "delete":
                id = Integer.parseInt(req.getParameter("id"));
                this.commentService.delete(id);
                resp.sendRedirect("/comment?method=list");
                break;
        }
    }
}
