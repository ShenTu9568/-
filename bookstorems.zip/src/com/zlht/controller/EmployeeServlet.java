package com.zlht.controller;

import com.zlht.entity.Employee;
import com.zlht.entity.Store;
import com.zlht.service.EmployeeService;
import com.zlht.service.StoreService;
import com.zlht.service.imp.EmployeeServiceImp;
import com.zlht.service.imp.StoreServiceImp;
import org.apache.taglibs.standard.extra.spath.Step;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {

    EmployeeService employeeService = new EmployeeServiceImp();
    StoreService storeService= new StoreServiceImp();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String method = req.getParameter("method");
        switch (method) {
            case "list":
                req.setAttribute("list", this.employeeService.list());
                req.setAttribute("storeList", this.storeService.list());
                req.getRequestDispatcher("employeemanager.jsp").forward(req, resp);
                break;
            case "search":
                String key = req.getParameter("key");
                String value = req.getParameter("value");
                req.setAttribute("list", this.employeeService.search(key, value));
                req.getRequestDispatcher("employeemanager.jsp").forward(req, resp);
                break;
            case "save":
                String name = req.getParameter("name");
                String gender = req.getParameter("gender");
                String age = req.getParameter("age");
                String phone = req.getParameter("phone");
                Integer store_id = Integer.parseInt(req.getParameter("storeId"));
                String position = req.getParameter("position");
                String username = req.getParameter("username");
                String password = req.getParameter("password");
                this.employeeService.save(new Employee(name,gender,age,phone,store_id,position,username,password));
                resp.sendRedirect("/employee?method=list");
                break;
            case "update":
                Integer id = Integer.parseInt(req.getParameter("id"));
                name = req.getParameter("name");
                gender = req.getParameter("gender");
                age = req.getParameter("age");
                phone = req.getParameter("phone");
                store_id = Integer.parseInt(req.getParameter("storeId"));
                position = req.getParameter("position");
                username = req.getParameter("username");
                password = req.getParameter("password");
                this.employeeService.update(new Employee(id,name,gender,age,phone,store_id,position,username,password));
                resp.sendRedirect("/employee?method=list");
                break;
            case "delete":
                id = Integer.parseInt(req.getParameter("id"));
                this.employeeService.delete(id);
                resp.sendRedirect("/employee?method=list");
                break;
        }
    }
}
