package com.zlht.controller;

import com.zlht.dto.StoreAdminDto;
import com.zlht.dto.SystemAccountDto;
import com.zlht.service.StoreAdminService;
import com.zlht.service.SystemAccountService;
import com.zlht.service.imp.StoreAdminServiceImp;
import com.zlht.service.imp.SystemAccountServiceImp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/account")
public class SystemAccountServlet extends HttpServlet {

    private SystemAccountService systemAccountService = new SystemAccountServiceImp();
    private StoreAdminService storeAdminService = new StoreAdminServiceImp();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("method");
        switch (method) {
            case "login":
                String username = req.getParameter("username");
                String password = req.getParameter("password");
                String type = req.getParameter("type");
                switch (type){
                    case "systemAdmin":
                        SystemAccountDto systemAccountDto = this.systemAccountService.login(username, password);
                        switch (systemAccountDto.getCode()) {
                            case -1:
                                req.setAttribute("usernameError","用户名不存在");
                                req.getRequestDispatcher("login.jsp").forward(req, resp);
                                break;
                            case 0:
                                req.setAttribute("passwordError","密码错误");
                                req.getRequestDispatcher("login.jsp").forward(req, resp);
                                break;
                            case 1:
                                HttpSession session = req.getSession() ;
                                session.setAttribute("systemAdmin", systemAccountDto.getSystemAccount());
                                resp.sendRedirect("/systemadmin.jsp");
                                break;
                        }
                        break;
                    case "storeAdmin":
                        StoreAdminDto storeAdminDto = this.storeAdminService.login(username, password);
                        switch (storeAdminDto.getCode()) {
                            case -1:
                                req.setAttribute("usernameError","用户名不存在");
                                req.getRequestDispatcher("login.jsp").forward(req, resp);
                                break;
                            case 0:
                                req.setAttribute("passwordError","密码错误");
                                req.getRequestDispatcher("login.jsp").forward(req, resp);
                                break;
                            case 1:
                                HttpSession session = req.getSession() ;
                                session.setAttribute("storeAdmin", storeAdminDto.getEmployee());
                                resp.sendRedirect("/storeadmin.jsp");
                                break;
                        }
                        break;
                }

                break;
            case "logout":
                req.getSession().invalidate();
                resp.sendRedirect("/login.jsp");
                break;
        }

    }
}
