package com.zlht.dao;

import com.zlht.entity.Author;

import java.util.List;

public interface AuthorDao {

    public List<Author> list();

    public List<Author> search(String key, String value);

    public Integer save(Author author);

    public Integer update(Author author);

    public Integer delete(Integer id);
}
