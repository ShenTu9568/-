package com.zlht.dao;

import com.zlht.entity.Book;
import com.zlht.entity.Employee;

import java.util.List;

public interface BookDao {

    public List<Book> list();
    public List<Book> search(String key, String value);
    public int save(Book book);
    public int update(Book book);
    public int delete(Integer id);
}
