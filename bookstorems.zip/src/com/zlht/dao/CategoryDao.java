package com.zlht.dao;

import com.zlht.entity.Category;
import com.zlht.entity.Store;

import java.util.List;

public interface CategoryDao {
    public List<Category> list();
    public List<Category> search(String key, String value);
    public Integer save(Category category);
    public Integer update(Category category);
    public Integer delete(Integer id);
}
