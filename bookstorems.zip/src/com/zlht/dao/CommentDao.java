package com.zlht.dao;

import com.zlht.entity.Book;
import com.zlht.entity.Comment;

import java.util.List;

public interface CommentDao {

    public List<Comment> list();
    public List<Comment> search(String key, String value);
    public int save(Comment comment);
    public int update(Comment comment);
    public int delete(Integer id);
}
