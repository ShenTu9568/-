package com.zlht.dao;

import com.zlht.entity.Customer;
import com.zlht.entity.Store;

import java.util.List;

public interface CustomerDao {

    public List<Customer> list();
    public List<Customer> search(String key, String value);
    public Integer save(Customer customer);
    public Integer update(Customer customer);
    public Integer delete(Integer id);
}
