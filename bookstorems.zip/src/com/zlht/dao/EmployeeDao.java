package com.zlht.dao;

import com.zlht.entity.Employee;

import java.util.List;

public interface EmployeeDao {
    public List<Employee> list();
    public List<Employee> search(String key, String value);
    public int save(Employee employee);
    public int update(Employee employee);
    public int delete(Integer id);

}
