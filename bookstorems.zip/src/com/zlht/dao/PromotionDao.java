package com.zlht.dao;

import com.zlht.entity.Promotion;
import com.zlht.entity.Store;

import java.util.List;

public interface PromotionDao {

    public List<Promotion> list();
    public List<Promotion> search(String key, String value);
    public Integer save(Promotion promotion);
    public Integer update(Promotion promotion);
    public Integer delete(Integer id);
}
