package com.zlht.dao;

import com.zlht.entity.Employee;
import com.zlht.entity.SystemAccount;

public interface StoreAdminDao {

    public Employee findByUsername(String username);
}
