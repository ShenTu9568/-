package com.zlht.dao;

import com.zlht.entity.Store;

import java.util.List;

public interface StoreDao {

    public List<Store> list();
    public List<Store> search(String key, String value);
    public Integer save(Store store);
    public Integer update(Store store);
    public Integer delete(Integer id);
}
