package com.zlht.dao;

import com.zlht.entity.SystemAccount;

public interface SystemAccountDao {
    public SystemAccount findByUsername(String username);
}
