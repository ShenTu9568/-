package com.zlht.dao;

import com.zlht.entity.Book;
import com.zlht.entity.Warehouse;

import java.util.List;

public interface WarehouseDao {
    public List<Warehouse> list();
    public List<Warehouse> search(String key, String value);
    public int save(Warehouse warehouse);
    public int update(Warehouse warehouse);
    public int delete(Integer id);
}
