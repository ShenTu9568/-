package com.zlht.dao.imp;

import com.zlht.dao.AuthorDao;
import com.zlht.entity.Author;
import com.zlht.entity.Category;
import com.zlht.entity.Store;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AuthorDaoImp implements AuthorDao {
    @Override
    public List<Author> list() {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from author";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Author> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String gender = resultSet.getString(3);
                String country = resultSet.getString(4);
                String introduce = resultSet.getString(5);

                list.add(new Author(id,name,gender,country,introduce));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public List<Author> search(String key, String value) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from author where "+key+" like '%"+value+"%'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Author> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String gender = resultSet.getString(3);
                String country = resultSet.getString(4);
                String introduce = resultSet.getString(5);

                list.add(new Author(id,name,gender,country,introduce));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public Integer save(Author author) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "insert into author (name,gender,country,introduce) values (?,?,?,?)";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,author.getName());
            statement.setString(2,author.getGender());
            statement.setString(3,author.getCountry());
            statement.setString(4,author.getIntroduce());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer update(Author author) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "update author set name = ?,gender = ?,country = ?,introduce = ? where id = ?";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,author.getName());
            statement.setString(2, author.getGender());
            statement.setString(3, author.getCountry());
            statement.setString(4,author.getIntroduce());
            statement.setInt(5,author.getId());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer delete(Integer id) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "delete from author where id = "+id;
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }
}
