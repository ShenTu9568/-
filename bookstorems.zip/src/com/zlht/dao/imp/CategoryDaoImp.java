package com.zlht.dao.imp;

import com.zlht.dao.CategoryDao;
import com.zlht.entity.Category;
import com.zlht.entity.Store;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryDaoImp implements CategoryDao {
    @Override
    public List<Category> list() {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from category";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Category> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String introduce = resultSet.getString(3);
                String position = resultSet.getString(4);

                list.add(new Category(id,name,introduce,position));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public List<Category> search(String key, String value) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from category where "+key+" like '%"+value+"%'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Category> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String introduce = resultSet.getString(3);
                String position = resultSet.getString(4);

                list.add(new Category(id,name,introduce,position));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public Integer save(Category category) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "insert into category (name,introduce,position) values (?,?,?)";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,category.getName());
            statement.setString(2,category.getIntroduce());
            statement.setString(3,category.getPosition());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer update(Category category) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "update category set name = ?,introduce = ?,position = ? where id =?";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,category.getName());
            statement.setString(2,category.getIntroduce());
            statement.setString(3,category.getPosition());
            statement.setInt(4,category.getId());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer delete(Integer id) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "delete from category where id = "+id;
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }
}
