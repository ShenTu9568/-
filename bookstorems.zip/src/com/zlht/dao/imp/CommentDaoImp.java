package com.zlht.dao.imp;

import com.zlht.dao.CommentDao;
import com.zlht.entity.Book;
import com.zlht.entity.Comment;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommentDaoImp implements CommentDao {
    @Override
    public List<Comment> list() {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select c.id,b.name,s.name,p.name,c.date,c.content from comment c,books b,store s,customer p where c.book_id = b.id and c.store_id = s.id and c.customer_id = p.id";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Comment> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String bookname = resultSet.getString(2);
                String storename = resultSet.getString(3);
                String customername = resultSet.getString(4);
                String date= resultSet.getString(5);
                String content = resultSet.getString(6);

                list.add(new Comment(id,bookname,storename,customername,date,content));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public List<Comment> search(String key, String value) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select c.id,b.name,s.name,p.name,c.date,c.content from comment c,books b,store s,customer p where c.book_id = b.id and c.store_id = s.id and c.customer_id = p.id and "+key+" like '%"+value+"%'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Comment> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String bookname = resultSet.getString(2);
                String storename = resultSet.getString(3);
                String customername = resultSet.getString(4);
                String date= resultSet.getString(5);
                String content = resultSet.getString(6);

                list.add(new Comment(id,bookname,storename,customername,date,content));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public int save(Comment comment) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "insert into comment (book_id,store_id,customer_id,date,content) values (?,?,?,?,?)";
        PreparedStatement statement = null;
        Integer result = null;
        try {
            statement = connection.prepareStatement(sql);
            statement.setInt(1, comment.getBook_id());
            statement.setInt(2, comment.getStore_id());
            statement.setInt(3, comment.getCustomer_id());
            statement.setString(4, comment.getDate());
            statement.setString(5, comment.getContent());

            result = statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection, statement, null);
        }
        return result;
    }

    @Override
    public int update(Comment comment) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "update comment set book_id = ?,store_id = ?,customer_id = ?,date = ?,content = ? where id = ?";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            statement.setInt(1, comment.getBook_id());
            statement.setInt(2, comment.getStore_id());
            statement.setInt(3, comment.getCustomer_id());
            statement.setString(4, comment.getDate());
            statement.setString(5, comment.getContent());
            statement.setInt(6, comment.getId());

            result = statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public int delete(Integer id) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "delete from comment where id = "+id;
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }
}
