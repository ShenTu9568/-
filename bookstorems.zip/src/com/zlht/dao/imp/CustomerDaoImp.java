package com.zlht.dao.imp;

import com.zlht.dao.CustomerDao;
import com.zlht.entity.Book;
import com.zlht.entity.Customer;
import com.zlht.entity.Store;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDaoImp implements CustomerDao {
    @Override
    public List<Customer> list() {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select id,name,gender,age,phone,email from customer";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Customer> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String gender = resultSet.getString(3);
                String age = resultSet.getString(4);
                String phone= resultSet.getString(5);
                String email = resultSet.getString(6);

                list.add(new Customer(id,name,gender,age,phone,email));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public List<Customer> search(String key, String value) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select id,name,gender,age,phone,email from customer where "+key+" like '%"+value+"%'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Customer> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String gender = resultSet.getString(3);
                String age = resultSet.getString(4);
                String phone= resultSet.getString(5);
                String email= resultSet.getString(6);

                list.add(new Customer(id,name,gender,age,phone,email));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public Integer save(Customer customer) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "insert into customer (name,gender,age,phone,email) values (?,?,?,?,?)";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,customer.getName());
            statement.setString(2,customer.getGender());
            statement.setString(3,customer.getAge());
            statement.setString(4,customer.getPhone());
            statement.setString(5,customer.getEmail());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer update(Customer customer) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "update customer set name = ?,gender = ?,age = ?,phone = ?,email = ? where id =?";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,customer.getName());
            statement.setString(2,customer.getGender());
            statement.setString(3,customer.getAge());
            statement.setString(4,customer.getPhone());
            statement.setString(5,customer.getEmail());
            statement.setInt(6,customer.getId());
            result = statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer delete(Integer id) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "delete from customer where id = "+id;
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }
}
