package com.zlht.dao.imp;

import com.zlht.dao.PromotionDao;
import com.zlht.entity.Category;
import com.zlht.entity.Promotion;
import com.zlht.entity.Store;
import com.zlht.entity.Warehouse;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PromotionDaoImp implements PromotionDao {
    @Override
    public List<Promotion> list() {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from promotion";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Promotion> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String description = resultSet.getString(3);
                String start = resultSet.getString(4);
                String end = resultSet.getString(5);
                String discount = resultSet.getString(6);

                list.add(new Promotion(id,name,description,start,end,discount));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public List<Promotion> search(String key, String value) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from promotion where "+key+" like '%"+value+"%'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Promotion> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String description = resultSet.getString(3);
                String start = resultSet.getString(4);
                String end = resultSet.getString(5);
                String discount = resultSet.getString(6);

                list.add(new Promotion(id,name,description,start,end,discount));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public Integer save(Promotion promotion) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "insert into promotion (name,description,start,end,discount) values (?,?,?,?,?)";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,promotion.getName());
            statement.setString(2,promotion.getDescription());
            statement.setString(3,promotion.getStart());
            statement.setString(4,promotion.getEnd());
            statement.setString(5,promotion.getDiscount());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer update(Promotion promotion) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "update promotion set name = ?,description = ?,start = ?,end = ?,discount = ? where id = ?";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,promotion.getName());
            statement.setString(2,promotion.getDescription());
            statement.setString(3,promotion.getStart());
            statement.setString(4,promotion.getEnd());
            statement.setString(5,promotion.getDiscount());
            statement.setInt(6,promotion.getId());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer delete(Integer id) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "delete from promotion where id = "+id;
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }
}
