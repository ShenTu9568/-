package com.zlht.dao.imp;

import com.zlht.dao.StoreAdminDao;
import com.zlht.entity.Employee;
import com.zlht.entity.SystemAccount;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StoreAdminDaoImp implements StoreAdminDao {

    @Override
    public Employee findByUsername(String username) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from employee where username = '"+username+"'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            if(resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String gender = resultSet.getString(3);
                String age = resultSet.getString(4);
                String phone = resultSet.getString(5);
                Integer store_id = resultSet.getInt(6);
                String position = resultSet.getString(7);
                username = resultSet.getString(8);
                String password = resultSet.getString(9);

                return new Employee(id,name,gender,age,phone,store_id,position,username,password);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return null;
    }
}
