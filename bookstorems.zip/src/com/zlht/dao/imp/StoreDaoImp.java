package com.zlht.dao.imp;

import com.zlht.dao.StoreDao;
import com.zlht.entity.Store;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StoreDaoImp implements StoreDao {
    @Override
    public List<Store> list() {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from store";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Store> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String adminName = resultSet.getString(3);
                String phone = resultSet.getString(4);
                String location= resultSet.getString(5);

                list.add(new Store(id,name,adminName,phone,location));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public List<Store> search(String key, String value) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from store where "+key+" like '%"+value+"%'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Store> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String adminName = resultSet.getString(3);
                String phone = resultSet.getString(4);
                String location= resultSet.getString(5);

                list.add(new Store(id,name,adminName,phone,location));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public Integer save(Store store) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "insert into store (name,adminname,phone,location) values (?,?,?,?)";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,store.getName());
            statement.setString(2,store.getAdminName());
            statement.setString(3,store.getPhone());
            statement.setString(4,store.getLocation());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer update(Store store) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "update store set name = ?,adminName = ?,phone = ?,location = ? where id =?";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1,store.getName());
            statement.setString(2,store.getAdminName());
            statement.setString(3,store.getPhone());
            statement.setString(4,store.getLocation());
            statement.setInt(5,store.getId());

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public Integer delete(Integer id) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "delete from store where id = "+id;
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }
}
