package com.zlht.dao.imp;

import com.zlht.dao.SystemAccountDao;
import com.zlht.entity.SystemAccount;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SystemAccountDaoImp implements SystemAccountDao {

    @Override
    public SystemAccount findByUsername(String username) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select * from systemaccount where username = '"+username+"'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            if(resultSet.next()){

                int id = resultSet.getInt(1);
                username= resultSet.getString(2);
                String password = resultSet.getString(3);
                String name = resultSet.getString(4);
                String phone = resultSet.getString(5);

                return new SystemAccount(id,username,password,name,phone);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return null;
    }
}
