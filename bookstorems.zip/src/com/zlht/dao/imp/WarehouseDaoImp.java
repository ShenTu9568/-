package com.zlht.dao.imp;

import com.zlht.dao.WarehouseDao;
import com.zlht.entity.Book;
import com.zlht.entity.Warehouse;
import com.zlht.util.JDBCUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class WarehouseDaoImp implements WarehouseDao {
    @Override
    public List<Warehouse> list() {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select w.id,w.name,b.name,w.address,w.number from warehouse w,books b where w.book_id = b.id";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Warehouse> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String book = resultSet.getString(3);
                String address = resultSet.getString(4);
                int number = resultSet.getInt(5);

                list.add(new Warehouse(id,name,book,address,number));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public List<Warehouse> search(String key, String value) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "select w.id,w.name,b.name,w.address,w.number from warehouse w,books b where w.book_id = b.id and "+key+" like '%"+value+"%'";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<Warehouse> list = new ArrayList<>();
        try{
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery();

            while (resultSet.next()){

                int id = resultSet.getInt(1);
                String name = resultSet.getString(2);
                String book = resultSet.getString(3);
                String address = resultSet.getString(4);
                int number = resultSet.getInt(5);

                list.add(new Warehouse(id,name,book,address,number));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,resultSet);
        }
        return list;
    }

    @Override
    public int save(Warehouse warehouse) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "insert into warehouse (name,book_id,address,number) values (?,?,?,?)";
        PreparedStatement statement = null;
        Integer result = null;
        try {
            statement = connection.prepareStatement(sql);
            statement.setString(1, warehouse.getName());
            statement.setInt(2, warehouse.getBookId());
            statement.setString(3, warehouse.getAddress());
            statement.setInt(4, warehouse.getNumber());

            result = statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection, statement, null);
        }
        return result;
    }

    @Override
    public int update(Warehouse warehouse) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "update warehouse set name = ?,book_id = ?,address = ?,number = ? where id = ?";
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);
            statement.setString(1, warehouse.getName());
            statement.setInt(2, warehouse.getBookId());
            statement.setString(3, warehouse.getAddress());
            statement.setInt(4, warehouse.getNumber());
            statement.setInt(5, warehouse.getId());

            result = statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }

    @Override
    public int delete(Integer id) {
        Connection connection = JDBCUtil.getConnection();
        String sql = "delete from warehouse where id = "+id;
        PreparedStatement statement = null;
        Integer result = null;
        try{
            statement = connection.prepareStatement(sql);

            result =statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.release(connection,statement,null);
        }
        return result;
    }
}
