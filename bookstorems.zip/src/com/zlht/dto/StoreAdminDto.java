package com.zlht.dto;

import com.zlht.entity.Employee;

public class StoreAdminDto {

    private  Integer code;
    private Employee employee;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
}
