package com.zlht.dto;

import com.zlht.entity.SystemAccount;

public class SystemAccountDto {
    private  Integer code;
    private SystemAccount systemAccount;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public SystemAccount getSystemAccount() {
        return systemAccount;
    }

    public void setSystemAccount(SystemAccount account) {
        this.systemAccount = account;
    }
}
