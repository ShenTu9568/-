package com.zlht.entity;

public class Book {
    private Integer id;
    private String name;
    private Integer author_id;
    private String author;
    private String price;
    private String publisher;
    private String date;
    private Integer category_id;
    private String category;

    public Book(Integer id, String name, Integer author_id, String price, String publisher, String date, Integer category_id) {
        this.id = id;
        this.name = name;
        this.author_id = author_id;
        this.price = price;
        this.publisher = publisher;
        this.date = date;
        this.category_id = category_id;
    }

    public Book(String name, Integer author_id, String price, String publisher, String date, Integer category_id) {
        this.name = name;
        this.author_id = author_id;
        this.price = price;
        this.publisher = publisher;
        this.date = date;
        this.category_id = category_id;
    }

    public Book(Integer id, String name, String author, String price, String publisher, String date, String category) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.price = price;
        this.publisher = publisher;
        this.date = date;
        this.category = category;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(Integer author_id) {
        this.author_id = author_id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getCategory_id() {
        return category_id;
    }

    public void setCategory_id(Integer category_id) {
        this.category_id = category_id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
