package com.zlht.entity;

public class Comment {
    private Integer id;
    private Integer book_id;
    private String bookname;
    private Integer store_id;
    private String storename;
    private Integer customer_id;
    private String customername;
    private String date;
    private String content;

    public Comment(Integer id, Integer book_id, Integer store_id, Integer customer_id, String date, String content) {
        this.id = id;
        this.book_id = book_id;
        this.store_id = store_id;
        this.customer_id = customer_id;
        this.date = date;
        this.content = content;
    }

    public Comment(Integer book_id, Integer store_id, Integer customer_id, String date, String content) {
        this.book_id = book_id;
        this.store_id = store_id;
        this.customer_id = customer_id;
        this.date = date;
        this.content = content;
    }

    public Comment(Integer id, String bookname, String storename, String customername, String date, String content) {
        this.id = id;
        this.bookname = bookname;
        this.storename = storename;
        this.customername = customername;
        this.date = date;
        this.content = content;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBook_id() {
        return book_id;
    }

    public void setBook_id(Integer book_id) {
        this.book_id = book_id;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public Integer getStore_id() {
        return store_id;
    }

    public void setStore_id(Integer store_id) {
        this.store_id = store_id;
    }

    public String getStorename() {
        return storename;
    }

    public void setStorename(String storename) {
        this.storename = storename;
    }

    public Integer getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(Integer customer_id) {
        this.customer_id = customer_id;
    }

    public String getCustomername() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
