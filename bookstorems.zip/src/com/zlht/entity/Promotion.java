package com.zlht.entity;

public class Promotion {

    private Integer id;
    private String name;
    private String description;
    private String start;
    private String end;
    private String discount;

    public Promotion(String name, String description, String start, String end, String discount) {
        this.name = name;
        this.description = description;
        this.start = start;
        this.end = end;
        this.discount = discount;
    }

    public Promotion(Integer id, String name, String description, String start, String end, String discount) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.start = start;
        this.end = end;
        this.discount = discount;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }
}
