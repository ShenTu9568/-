package com.zlht.entity;

public class Store {

    private Integer id;
    private String name;
    private String adminName;
    private String phone;
    private String location;

    public Store(String name, String adminName, String phone, String location) {
        this.name = name;
        this.adminName = adminName;
        this.phone = phone;
        this.location = location;
    }

    public Store(Integer id, String name, String adminName, String phone, String location) {
        this.id = id;
        this.name = name;
        this.adminName = adminName;
        this.phone = phone;
        this.location = location;

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
