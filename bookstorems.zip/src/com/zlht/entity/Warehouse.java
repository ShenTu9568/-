package com.zlht.entity;

public class Warehouse {

    private Integer id;
    private String name;
    private Integer bookId;
    private String book;
    private String address;
    private Integer number;

    public Warehouse(Integer id, String name, String book, String address, Integer number) {
        this.id = id;
        this.name = name;
        this.book = book;
        this.address = address;
        this.number = number;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public String getBook() {
        return book;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public Warehouse(Integer id, String name, Integer bookId, String address, Integer number) {
        this.id = id;
        this.name = name;
        this.bookId = bookId;
        this.address = address;
        this.number = number;
    }

    public Warehouse(String name, Integer bookId, String address, Integer number) {
        this.name = name;
        this.bookId = bookId;
        this.address = address;
        this.number = number;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
