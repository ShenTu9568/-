package com.zlht.service;

import com.zlht.entity.Author;

import java.util.List;

public interface AuthorService {

    public List<Author> list();

    public List<Author> search(String key, String value);

    public void save(Author author);

    public void update(Author author);

    public void delete(Integer id);
}
