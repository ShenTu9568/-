package com.zlht.service;

import com.zlht.entity.Book;

import java.util.List;

public interface BookService {

    public List<Book> list();
    public List<Book> search(String key, String value);
    public void save(Book book);
    public void update(Book book);
    public void delete(Integer id);
}
