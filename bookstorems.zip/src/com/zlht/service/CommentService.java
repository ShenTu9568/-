package com.zlht.service;

import com.zlht.entity.Book;
import com.zlht.entity.Comment;

import java.util.List;

public interface CommentService {

    public List<Comment> list();
    public List<Comment> search(String key, String value);
    public void save(Comment comment);
    public void update(Comment comment);
    public void delete(Integer id);
}
