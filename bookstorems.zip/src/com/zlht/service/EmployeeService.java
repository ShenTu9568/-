package com.zlht.service;

import com.zlht.entity.Employee;

import java.util.List;

public interface EmployeeService {
    public List<Employee> list();
    public List<Employee> search(String key, String value);
    public void save(Employee employee);
    public void update(Employee employee);
    public void delete(Integer id);
}
