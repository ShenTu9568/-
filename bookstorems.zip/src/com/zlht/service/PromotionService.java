package com.zlht.service;

import com.zlht.entity.Promotion;
import com.zlht.entity.Store;

import java.util.List;

public interface PromotionService {

    public List<Promotion> list();
    public List<Promotion> search(String key, String value);
    public void save(Promotion promotion);
    public void update(Promotion promotion);
    public void delete(Integer id);
}
