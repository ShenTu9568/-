package com.zlht.service;

import com.zlht.dto.StoreAdminDto;

public interface StoreAdminService {

    public StoreAdminDto login(String username, String password);
}
