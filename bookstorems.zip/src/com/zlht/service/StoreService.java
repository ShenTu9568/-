package com.zlht.service;

import com.zlht.entity.Store;

import java.util.List;

public interface StoreService {
    public List<Store> list();
    public List<Store> search(String key, String value);
    public void save(Store store);
    public void update(Store store);
    public void delete(Integer id);
}
