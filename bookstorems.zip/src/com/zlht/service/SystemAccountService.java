package com.zlht.service;


import com.zlht.dto.SystemAccountDto;

public interface SystemAccountService {
    public SystemAccountDto login(String username, String password);
}
