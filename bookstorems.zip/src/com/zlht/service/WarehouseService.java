package com.zlht.service;

import com.zlht.entity.Book;
import com.zlht.entity.Warehouse;

import java.util.List;

public interface WarehouseService {
    public List<Warehouse> list();
    public List<Warehouse> search(String key, String value);
    public void save(Warehouse warehouse);
    public void update(Warehouse warehouse);
    public void delete(Integer id);
}
