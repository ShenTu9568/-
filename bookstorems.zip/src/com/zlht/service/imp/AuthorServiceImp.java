package com.zlht.service.imp;

import com.zlht.dao.AuthorDao;
import com.zlht.dao.imp.AuthorDaoImp;
import com.zlht.entity.Author;
import com.zlht.service.AuthorService;

import java.util.List;

public class AuthorServiceImp implements AuthorService {

    AuthorDao authorDao = new AuthorDaoImp();

    @Override
    public List<Author> list() {
        return this.authorDao.list();
    }

    @Override
    public List<Author> search(String key, String value) {
        if(value.equals("")) return this.authorDao.list();
        return this.authorDao.search(key, value);
    }

    @Override
    public void save(Author author) {
        Integer save = this.authorDao.save(author);
        if (save != 1) throw new RuntimeException("作者信息添加失败");
    }

    @Override
    public void update(Author author) {
        Integer update = this.authorDao.update(author);
        if (update != 1) throw new RuntimeException("作者信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer delete = this.authorDao.delete(id);
        if (delete != 1) throw new RuntimeException("作者信息删除失败");
    }
}
