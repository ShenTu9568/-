package com.zlht.service.imp;

import com.zlht.dao.BookDao;
import com.zlht.dao.imp.BookDaoImp;
import com.zlht.entity.Book;
import com.zlht.entity.Employee;
import com.zlht.service.BookService;

import java.util.List;

public class BookServiceImp implements BookService {

    BookDao bookDao = new BookDaoImp();

    @Override
    public List<Book> list() {
        return this.bookDao.list();
    }

    @Override
    public List<Book> search(String key, String value) {
        if(value.equals("")) return this.bookDao.list();
        return this.bookDao.search(key, value);
    }

    @Override
    public void save(Book book) {
        Integer save = this.bookDao.save(book);
        if( save != 1 ) throw new RuntimeException("书籍信息添加失败");
    }

    @Override
    public void update(Book book) {
        Integer update = this.bookDao.update(book);
        if( update != 1 ) throw new RuntimeException("书籍信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer update = this.bookDao.delete(id);
        if( update != 1 ) throw new RuntimeException("书籍信息删除失败");
    }
}
