package com.zlht.service.imp;

import com.zlht.dao.CategoryDao;
import com.zlht.dao.imp.CategoryDaoImp;
import com.zlht.entity.Category;
import com.zlht.service.CategoryService;

import java.util.List;

public class CategoryServiceImp implements CategoryService {

    CategoryDao categoryDao = new CategoryDaoImp();

    @Override
    public List<Category> list() {
        return this.categoryDao.list();
    }

    @Override
    public List<Category> search(String key, String value) {
        if(value.equals("")) return this.categoryDao.list();
        return this.categoryDao.search(key ,value);
    }

    @Override
    public void save(Category category) {
        Integer save = this.categoryDao.save(category);
        if( save != 1 ) throw new RuntimeException("类型信息添加失败");
    }

    @Override
    public void update(Category category) {
        Integer update = this.categoryDao.update(category);
        if( update != 1 ) throw new RuntimeException("类型信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer delete = this.categoryDao.delete(id);
        if( delete != 1 ) throw new RuntimeException("类型信息删除失败");
    }
}
