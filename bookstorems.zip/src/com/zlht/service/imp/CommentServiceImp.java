package com.zlht.service.imp;

import com.zlht.dao.CommentDao;
import com.zlht.dao.imp.CommentDaoImp;
import com.zlht.entity.Book;
import com.zlht.entity.Comment;
import com.zlht.service.CommentService;

import java.util.List;

public class CommentServiceImp implements CommentService {

    CommentDao commentDao = new CommentDaoImp();

    @Override
    public List<Comment> list() {
        return this.commentDao.list();
    }

    @Override
    public List<Comment> search(String key, String value) {
        if (value.equals("")) return this.commentDao.list();
        return this.commentDao.search(key, value);
    }

    @Override
    public void save(Comment comment) {
        Integer save = this.commentDao.save(comment);
        if (save != 1) throw new RuntimeException("评论信息添加失败");
    }

    @Override
    public void update(Comment comment) {
        Integer update = this.commentDao.update(comment);
        if (update != 1) throw new RuntimeException("评论信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer update = this.commentDao.delete(id);
        if (update != 1) throw new RuntimeException("评论信息删除失败");
    }
}
