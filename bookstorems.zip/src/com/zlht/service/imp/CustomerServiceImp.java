package com.zlht.service.imp;

import com.zlht.dao.CustomerDao;
import com.zlht.dao.imp.CustomerDaoImp;
import com.zlht.entity.Customer;
import com.zlht.service.CustomerService;

import java.util.List;

public class CustomerServiceImp implements CustomerService {

    CustomerDao customerDao = new CustomerDaoImp();

    @Override
    public List<Customer> list() {
        return this.customerDao.list();
    }

    @Override
    public List<Customer> search(String key, String value) {
        if(value.equals("")) return this.customerDao.list();
        return this.customerDao.search(key ,value);
    }

    @Override
    public void save(Customer customer) {
        Integer save = this.customerDao.save(customer);
        if( save != 1 ) throw new RuntimeException("顾客信息添加失败");
    }

    @Override
    public void update(Customer customer) {
        Integer update = this.customerDao.update(customer);
        if( update != 1 ) throw new RuntimeException("顾客信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer delete = this.customerDao.delete(id);
        if( delete != 1 ) throw new RuntimeException("顾客信息删除失败");
    }
}
