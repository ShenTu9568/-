package com.zlht.service.imp;

import com.zlht.dao.EmployeeDao;
import com.zlht.dao.imp.EmployeeDaoImp;
import com.zlht.entity.Employee;
import com.zlht.service.EmployeeService;

import java.util.List;

public class EmployeeServiceImp implements EmployeeService {

    EmployeeDao employeeDao = new EmployeeDaoImp();
    @Override
    public List<Employee> list() {
        return this.employeeDao.list();
    }

    @Override
    public List<Employee> search(String key, String value) {
        if(value.equals("")) return this.employeeDao.list();
        return this.employeeDao.search(key, value);
    }

    @Override
    public void save(Employee employee) {
        Integer save = this.employeeDao.save(employee);
        if( save != 1 ) throw new RuntimeException("员工信息添加失败");
    }

    @Override
    public void update(Employee employee) {
        Integer update = this.employeeDao.update(employee);
        if( update != 1 ) throw new RuntimeException("员工信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer update = this.employeeDao.delete(id);
        if( update != 1 ) throw new RuntimeException("员工信息删除失败");
    }
}
