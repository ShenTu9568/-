package com.zlht.service.imp;

import com.zlht.dao.PromotionDao;
import com.zlht.dao.imp.PromotionDaoImp;
import com.zlht.entity.Promotion;
import com.zlht.service.PromotionService;

import java.util.List;

public class PromotionServiceImp implements PromotionService {

    PromotionDao promotionDao = new PromotionDaoImp();

    @Override
    public List<Promotion> list() {
        return this.promotionDao.list();
    }

    @Override
    public List<Promotion> search(String key, String value) {
        if(value.equals("")) return this.promotionDao.list();
        return this.promotionDao.search(key ,value);
    }

    @Override
    public void save(Promotion promotion) {
        Integer save = this.promotionDao.save(promotion);
        if( save != 1 ) throw new RuntimeException("活动信息添加失败");
    }

    @Override
    public void update(Promotion promotion) {
        Integer update = this.promotionDao.update(promotion);
        if( update != 1 ) throw new RuntimeException("活动信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer delete = this.promotionDao.delete(id);
        if( delete != 1 ) throw new RuntimeException("活动信息删除失败");
    }
}
