package com.zlht.service.imp;

import com.zlht.dao.StoreAdminDao;
import com.zlht.dao.imp.StoreAdminDaoImp;
import com.zlht.dto.StoreAdminDto;
import com.zlht.dto.SystemAccountDto;
import com.zlht.entity.Employee;
import com.zlht.entity.SystemAccount;
import com.zlht.service.StoreAdminService;

public class StoreAdminServiceImp implements StoreAdminService{

    StoreAdminDao storeAdminDao = new StoreAdminDaoImp();

    @Override
    public StoreAdminDto login(String username, String password) {
        //1、通过account_name查询数据库
        //2、查询结果为空，account_name错误
        //3、查询结果不为空，再判断password是否正确
        Employee employee = this.storeAdminDao.findByUsername(username);
        StoreAdminDto storeAdminDto = new StoreAdminDto();
        if(employee == null){
            storeAdminDto.setCode(-1);  //用户名不存在
        }else {
            if( ! employee.getPassword().equals(password)){
                storeAdminDto.setCode(0);   //密码错误
            } else{
                storeAdminDto.setCode(1);
                storeAdminDto.setEmployee(employee);
            }
        }
        return storeAdminDto;
    }
}
