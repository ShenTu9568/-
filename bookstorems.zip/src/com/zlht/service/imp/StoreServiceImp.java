package com.zlht.service.imp;

import com.zlht.dao.StoreDao;
import com.zlht.dao.imp.StoreDaoImp;
import com.zlht.entity.Store;
import com.zlht.service.StoreService;

import java.util.List;

public class StoreServiceImp implements StoreService {

    private StoreDao storeDao = new StoreDaoImp();

    @Override
    public List<Store> list() {
        return this.storeDao.list();
    }

    @Override
    public List<Store> search(String key, String value) {
        if(value.equals("")) return this.storeDao.list();
        return this.storeDao.search(key ,value);
    }

    @Override
    public void save(Store store) {
         Integer save = this.storeDao.save(store);
         if( save != 1 ) throw new RuntimeException("店铺信息添加失败");
    }

    @Override
    public void update(Store store) {
        Integer update = this.storeDao.update(store);
        if( update != 1 ) throw new RuntimeException("店铺信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer delete = this.storeDao.delete(id);
        if( delete != 1 ) throw new RuntimeException("店铺信息删除失败");
    }
}
