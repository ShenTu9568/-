package com.zlht.service.imp;

import com.zlht.dao.SystemAccountDao;
import com.zlht.dao.imp.SystemAccountDaoImp;
import com.zlht.dto.SystemAccountDto;
import com.zlht.entity.SystemAccount;
import com.zlht.service.SystemAccountService;

public class SystemAccountServiceImp implements SystemAccountService {

    private SystemAccountDao systemAccountDao = new SystemAccountDaoImp();

    @Override
    public SystemAccountDto login(String username, String password) {
        //1、通过account_name查询数据库
        //2、查询结果为空，account_name错误
        //3、查询结果不为空，再判断password是否正确
        SystemAccount systemAccount = this.systemAccountDao.findByUsername(username);
        SystemAccountDto systemAccountDto = new SystemAccountDto();
        if(systemAccount == null){
           systemAccountDto.setCode(-1);  //用户名不存在
        }else {
            if( ! systemAccount.getPassword().equals(password)){
                systemAccountDto.setCode(0);   //密码错误
            } else{
                systemAccountDto.setCode(1);
                systemAccountDto.setSystemAccount(systemAccount);
            }
        }
        return systemAccountDto;
    }
}
