package com.zlht.service.imp;

import com.zlht.dao.WarehouseDao;
import com.zlht.dao.imp.WarehouseDaoImp;
import com.zlht.entity.Book;
import com.zlht.entity.Warehouse;
import com.zlht.service.WarehouseService;

import java.util.List;

public class WarehouseServiceImp implements WarehouseService {

    WarehouseDao warehouseDao = new WarehouseDaoImp();

    @Override
    public List<Warehouse> list() {
        return this.warehouseDao.list();
    }

    @Override
    public List<Warehouse> search(String key, String value) {
        if(value.equals("")) return this.warehouseDao.list();
        return this.warehouseDao.search(key, value);
    }

    @Override
    public void save(Warehouse warehouse) {
        Integer save = this.warehouseDao.save(warehouse);
        if( save != 1 ) throw new RuntimeException("库存信息添加失败");
    }

    @Override
    public void update(Warehouse warehouse) {
        Integer update = this.warehouseDao.update(warehouse);
        if( update != 1 ) throw new RuntimeException("库存信息更新失败");
    }

    @Override
    public void delete(Integer id) {
        Integer update = this.warehouseDao.delete(id);
        if( update != 1 ) throw new RuntimeException("库存信息删除失败");

    }
}
